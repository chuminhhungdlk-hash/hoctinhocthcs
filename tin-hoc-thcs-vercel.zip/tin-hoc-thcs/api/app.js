import {put,list} from '@vercel/blob';
import {createHmac,createHash,createCipheriv,createDecipheriv,randomBytes} from 'node:crypto';
const SEC=process.env.AUTH_SECRET||'',TH=process.env.TEACHER_HASH||'',GK=process.env.GEMINI_API_KEY||'',OK=process.env.OPENAI_API_KEY||'';
const GM=[process.env.GEMINI_MODEL,'gemini-3-flash-preview','gemini-3.8-flash','gemini-3.7-flash','gemini-3.6-flash','gemini-3.5-flash','gemini-3.1-flash-lite','gemini-flash-latest'].filter(Boolean),OM=[process.env.OPENAI_MODEL,'gpt-5-mini','gpt-4o-mini'].filter(Boolean);
const hm=s=>createHmac('sha256',SEC).update(s).digest('hex'),NS='d/'+hm('ns').slice(0,20)+'/',EK=createHash('sha256').update(SEC+'|keys').digest();
const sign=o=>{const p=Buffer.from(JSON.stringify(o)).toString('base64url');return p+'.'+hm(p)};
const ver=h=>{const[p,s]=String(h||'').replace(/^Bearer /,'').split('.');if(!p||s!==hm(p))return null;try{const o=JSON.parse(Buffer.from(p,'base64url'));return o.e>Date.now()?o:null}catch{return null}};
const rd=async n=>{const{blobs}=await list({prefix:NS+n,limit:1});return blobs[0]?fetch(blobs[0].url+'?t='+Date.now(),{cache:'no-store'}).then(r=>r.ok?r.json():null):null};
const wr=(n,v)=>put(NS+n,JSON.stringify(v),{access:'public',addRandomSuffix:false,allowOverwrite:true,contentType:'application/json',cacheControlMaxAge:60});
const fn=c=>'r/'+String(c).replace(/[^\w-]/g,'_')+'.json',kid=u=>'k/'+(u.r=='t'?'teacher':String(u.c).replace(/[^\w-]/g,'_'))+'.json';
const enc=t=>{const iv=randomBytes(12),c=createCipheriv('aes-256-gcm',EK,iv),d=Buffer.concat([c.update(t,'utf8'),c.final()]);return[iv,c.getAuthTag(),d].map(x=>x.toString('base64')).join('.')};
const dec=s=>{try{const[iv,tg,d]=s.split('.').map(x=>Buffer.from(x,'base64')),c=createDecipheriv('aes-256-gcm',EK,iv);c.setAuthTag(tg);return Buffer.concat([c.update(d),c.final()]).toString('utf8')}catch{return''}};
const pj=async(u,h,b)=>{const r=await fetch(u,{method:'POST',headers:{'content-type':'application/json',...h},body:JSON.stringify(b),signal:AbortSignal.timeout(45000)});if(!r.ok){const e=new Error(r.status+' '+(await r.text()).replace(/\s+/g,' ').slice(0,140));e.st=r.status;throw e}return r.json()};
const gem=async(key,p,n)=>{let err;for(const m of GM)for(const th of [{thinkingLevel:'minimal'},null]){try{const r=await pj(`https://generativelanguage.googleapis.com/v1beta/models/${m}:generateContent`,{'x-goog-api-key':key},{contents:[{parts:[{text:p}]}],generationConfig:{maxOutputTokens:n,responseMimeType:'application/json',...(th?{thinkingConfig:th}:{})}}),t=(r.candidates?.[0]?.content?.parts||[]).map(x=>x.text||'').join('');if(t)return t;break}catch(e){err=e;if(e.st==400&&th)continue;if(e.st==401||e.st==403)throw e;break}}throw err||new Error('rỗng')};
const oai=async(key,p,n)=>{let err;for(const m of OM){try{const r=await pj('https://api.openai.com/v1/chat/completions',{authorization:'Bearer '+key},{model:m,messages:[{role:'user',content:p}],max_completion_tokens:n}),t=r.choices?.[0]?.message?.content;if(t)return t}catch(e){err=e;if(e.st==401)throw e}}throw err||new Error('rỗng')};
async function ask(u,p,n){const mine=(await rd(kid(u)))||{},T=[];
if(mine.gemini)T.push(['Gemini của tài khoản',()=>gem(dec(mine.gemini),p,n)]);if(mine.openai)T.push(['OpenAI của tài khoản',()=>oai(dec(mine.openai),p,n)]);
if(GK)T.push(['Gemini',()=>gem(GK,p,n)]);if(OK)T.push(['OpenAI',()=>oai(OK,p,n)]);
const E=[];for(const[l,f]of T)try{return await f()}catch(e){E.push(l+': '+String(e.message||e).slice(0,110))}
throw new Error(T.length?E.join(' | '):'Chưa có khóa AI. Hãy thêm khóa ở nút Khóa AI.')}
export default async function handler(req,res){
const no=(c,e)=>res.status(c).json({e});
try{
if(req.method!=='POST')return no(405,'method');
if(!SEC)return no(500,'config:AUTH_SECRET');
const b=typeof req.body=='string'?JSON.parse(req.body||'{}'):req.body||{},op=b.op,u=ver(req.headers.authorization);
if(op=='classes'){const r=(await rd('roster.json'))||[];return res.json({list:[...new Set(r.map(s=>{const a=s.split('|');return'||'+a[2]+'|'+a[3]}))]})}
if(op=='login'){const r=(await rd('roster.json'))||[],c=String(b.c||'').trim().toUpperCase(),x=r.map(s=>s.split('|')).find(a=>a[0].toUpperCase()==c&&a[2]==b.k&&a[3]==b.l);if(!x)return no(401,'no');return res.json({token:sign({r:'s',c:x[0],e:Date.now()+432e5}),c:x[0],n:x[1]})}
if(op=='tlogin'){const h=createHash('sha256').update('tin6789|'+b.u+':'+b.p).digest('hex');if(!TH||h!==TH)return no(401,'no');return res.json({token:sign({r:'t',e:Date.now()+288e5})})}
if(!u)return no(401,'auth');
if(op=='ai'){try{return res.json({text:await ask(u,String(b.prompt||'').slice(0,12000),b.tier=='quick'?4000:10000)})}catch(e){return no(502,'ai:'+String(e.message||e).slice(0,420))}}
if(op=='keys'){const m=(await rd(kid(u)))||{},mk=s=>s?'••••'+dec(s).slice(-4):null;return res.json({gemini:mk(m.gemini),openai:mk(m.openai)})}
if(op=='setKey'){const p=b.p,k=String(b.k||'').trim();if(!['gemini','openai'].includes(p)||k.length<10||k.length>300)return no(400,'Khóa không hợp lệ');
const ok=await fetch(p=='gemini'?'https://generativelanguage.googleapis.com/v1beta/models?pageSize=1':'https://api.openai.com/v1/models',{headers:p=='gemini'?{'x-goog-api-key':k}:{authorization:'Bearer '+k},signal:AbortSignal.timeout(15000)}).then(r=>r.ok).catch(()=>false);
if(!ok)return no(400,'Khóa không đúng hoặc không dùng được');const m=(await rd(kid(u)))||{};m[p]=enc(k);await wr(kid(u),m);return res.json({ok:1})}
if(op=='delKey'){const m=(await rd(kid(u)))||{};delete m[b.p];await wr(kid(u),m);return res.json({ok:1})}
if(u.r=='s'){
if(op=='mine')return res.json({a:(await rd(fn(u.c)))||[]});
if(op=='save'){const a=(Array.isArray(b.list)?b.list:[]).filter(r=>r&&r.c===u.c&&typeof r.id=='string'&&r.s>=0&&r.s<=100).slice(-150);await wr(fn(u.c),a);return res.json({ok:a.length})}}
if(u.r=='t'){
if(op=='names'){const r=((await rd('roster.json'))||[]).map(x=>x.split('|'));return res.json({list:r.filter(x=>x[2]==b.k&&x[3]==b.l).map(x=>[x[1],x[4]||''])})}
if(op=='roster')return res.json({list:(await rd('roster.json'))||[]});
if(op=='setRoster'){const l=(Array.isArray(b.list)?b.list:[]).filter(s=>typeof s=='string'&&[4,5].includes(s.split('|').length)).slice(0,3000);await wr('roster.json',l);return res.json({ok:l.length})}
if(op=='results'){const all=[];let cur;do{const q=await list({prefix:NS+'r/',limit:1000,cursor:cur});cur=q.hasMore?q.cursor:null;for(let i=0;i<q.blobs.length;i+=25)(await Promise.all(q.blobs.slice(i,i+25).map(x=>fetch(x.url+'?t='+Date.now(),{cache:'no-store'}).then(r=>r.json()).catch(()=>[])))).forEach(a=>all.push(...a))}while(cur);return res.json({a:all})}}
return no(400,'op')
}catch(e){return no(500,'srv:'+String(e?.message||e).slice(0,160))}}
